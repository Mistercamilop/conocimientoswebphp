$(document).ready(function(){

	//Conocimientos
	 $('#Conocimientos').on('click' , function(){

		$('body, html').animate({

			scrollTop: '650px'
		},900);

	 });
	 //Biografia

	 $('#Biografia').on('click',function(){
          $('body,html').animate({
          	    scrollTop: '1200px'
          },900);
	 });

     //Contactenos
	 $('#Contactenos').on('click', function(){
	 	       $('body,html').animate({
	 	       	        scrollTop: '2600px'
	 	       },900);
	 });
});