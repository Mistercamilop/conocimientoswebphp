(document).ready(function(){
	 ('body,html').animate({
	 	  scrollTop: '0px';
	 });
});