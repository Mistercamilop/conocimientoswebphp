<?php 
   $Nombre = $_GET['nombre'];
   if (empty($Nombre) && isset($Nombre)) {
   	     header('Location: index.php');
   }
 ?>