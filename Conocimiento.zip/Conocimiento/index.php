<!DOCTYPE HTML>
<!--
	Autonomy by TEMPLATED
    templated.co @templatedco
    Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Autonomy by TEMPLATED</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
			<link rel="stylesheet" type="text/css" href="icon/style1.css">
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
	</head>
	<body class="homepage">

		<!-- Header -->
		<div id="header">
			<div class="container">

				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">Juan Camilo Penagos</a> <p>Desarrollo web</p></h1>
					
				</div>

				<!-- Nav -->
				<nav id="nav">
					<ul>
						<li class="active"><a href="index.html">Inico</a></li>
						<li><a href="#" id="Conocimientos">Conocimientos</a></li>
						<li><a href="#" id="Biografia">Biografia</a></li>
						<li><a href="#" id="Contactenos">Contactenos</a></li>
					</ul>
				</nav>

			</div>
		</div>

		<div id="banner">&nbsp;</div>
           <span class="icon-up"></span>
		<div id="featured">
			<div class="container">
				<div class="row">

					<div class="3u">
						<section>
							<a href="#" class="image full"><img src="images/bootstrap-logo.png" alt=""></a>
							<header>
								<h2>Booststrap</h2>
							</header>
							<p>Framework de html,css,js</p>				
						</section>
					</div>

					<div class="3u">
						<section>
							<a href="#" class="image full"><img src="images/maxresdefault.jpg" alt=""></a>
							<header>
								<h2>FLexbox Grid</h2>
							</header>
							<p>Framework de responsive y flexbox</p>				
						</section>
					</div>

					<div class="3u">
						<section>
							<a href="#" class="image full"><img src="images/images.jpg" alt=""></a>
							<header>
								<h2>PHP</h2>
							</header>
							<p>Lenguaje de progamacion del  lado del servidor</p>				
						</section>
					</div>

					<div class="3u">
						<section>
							<a href="#" class="image full"><img src="images/descarga.png" alt=""></a>
							<header>
								<h2>Jquery</h2>
							</header>
							<p>Libreria de javascript</p>				
						</section>
					</div>

				</div>
			</div>
		</div>
		<div id="marketing">
			<div class="container">
				<div class="row">
					<div class="3u">
						<section>
							<header>
								<h2>Metas</h2>
							</header>
							 <p>Terminar bien la tecnolia y la ingeniria y ser un gran  profecional en desarrolador web

							</p>
						</section>
					</div>
					<div class="3u">
						<section>
							<header>
								<h2>Hobbis</h2>
							</header>
							<ul class="style1">
								<li class="first">
									<p>-Jugar futbol</p>
								</li>
								<li>
									<p>-Hacer ejercisio </p>
								</li>
								<li>
									<p>-Cursos oline</p>
								</li>
							</ul>
						</section>
					</div>

					<div class="6u">
						<section>
							<header>
								<h2>Juean camilo penagos</h2>
							</header>
							<a href="#" class="image full"><img src="images/yo.jpg" alt=""></a>
							<p>Soy una persona alegre,puntal,positiva,comprometida que quiere ser una gran profecional en el mundo de la programacion y especialisarme en desarrollo web actualmente soy aprendiz del sena en la carrera teclongia en sistemas</p>
						</section>
					</div>

				</div>
			</div>
		</div>

		<div id="main">
			<div class="container">
				<div class="row">
					<div class="12u">
						  <section>
						  	<header>
								<h2>Contactenos</h2>
							</header>
						
						      <form action="procesa.php" method="GET" class="form"> 
						 	     <div class="4u">
						 	     	 <label id="Nombre" form="Nombre">Nombre</label>
						 	     	<input type="text" name="nombre" id="Nombre" placeholder="" class="<?php if(isset($_GET['nombre']) && empty($_GET['nombre'])) echo'error';?>">
						 	     </div>
						 	       <div class="4u">
						 	       	<label id="" form="Nombre" class="Nombre">Telefono</label>
						 	         <input type="number" name="telefono" id="Nombre" placeholder="<?php if(isset($_GET['Nombre'])){
                                             echo'Completar';
						 	     	} ?>" class="">
						 	       </div>
						 	      <label id="" form="Correo">Correo</label>
						 	      <input type="email" name="Correo" id="Nombre" placeholder="<?php if(isset($_POST['Nombre'])){
                                             echo'Completar';
						 	     	} ?>" class="<?php if(isset($_POST['Correo'])){
						 	     		      echo'error';
						 	     	} ?>">
						 	       <label id="" form="Mensaje">Mensaje</label>
                                   <textarea id="Mensaje" placeholder="Mensaje" name="Mensaje" class="<?php if(isset($_POST['Correo'])){
						 	     		      echo'error';
						 	     	} ?>">
                                   	        
                                   </textarea>

                                    <button type="submit" id="btn">Enviar</button>

						      </form>
						  
						  </section> 
					</div>

				</div>
			</div>
		</div>

		<!-- Copyright -->
		<div id="copyright">
			<div class="container">
				Design: <a href="http://templated.co">Camilo</a> Images: <a href="http://unsplash.com">Unsplash</a> (<a href="http://unsplash.com/cc0">CC0</a>)
			</div>
		</div>
 <script src="js/main.js"></script>
	</body>
</html>